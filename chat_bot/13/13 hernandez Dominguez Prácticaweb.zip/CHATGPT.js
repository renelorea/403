const chatBox = document.getElementById('chat-box');
const input = document.getElementById('user-input');

const respuestas = {
    "¿qué es una alimentación saludable?": "Es una alimentación que aporta todos los nutrientes necesarios para mantener el cuerpo sano.",
    "¿cuáles son los grupos de alimentos?": "Frutas, verduras, cereales, proteínas (como carne y legumbres), y lácteos.",
    "¿por qué es importante el agua?": "Porque hidrata el cuerpo y ayuda a que funcionen bien los órganos.",
    "¿qué es la pirámide alimenticia?": "Es una guía visual que muestra los grupos de alimentos y las porciones recomendadas.",
    "¿qué alimentos debo evitar?": "Alimentos ultraprocesados, con mucho azúcar, grasas saturadas y sal.",
    "¿cuántas comidas debo hacer al día?": "Lo ideal es hacer 5 comidas: desayuno, almuerzo, comida, merienda y cena.",
    "¿qué son los nutrientes?": "Son sustancias que el cuerpo necesita para funcionar correctamente: proteínas, grasas, carbohidratos, vitaminas y minerales.",
    "¿cómo leer etiquetas nutricionales?": "Debes fijarte en las calorías, azúcares, grasas y porciones por envase.",
    "¿qué es una dieta balanceada?": "Es una dieta que incluye alimentos variados en las proporciones adecuadas.",
    "¿qué alimentos ayudan a mejorar la memoria?": "Frutas, vegetales, pescado, nueces y alimentos ricos en omega 3."
};

function sendMessage() {
    const userText = input.value.trim().toLowerCase();
    if (!userText) return;

    addMessage(userText, 'user');

    const respuesta = respuestas[userText] || "Lo siento, no tengo una respuesta para esa pregunta. Intenta con otra sobre alimentación.";
    setTimeout(() => {
        addMessage(respuesta, 'bot');
    }, 500);

    input.value = '';
}

function addMessage(text, sender) {
    const msg = document.createElement('div');
    msg.className = 'chat-message ' + sender;
    msg.textContent = (sender === 'user' ? "Tú: " : "NutriAmigo: ") + text;
    chatBox.appendChild(msg);
    chatBox.scrollTop = chatBox.scrollHeight;
}
