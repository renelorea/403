const respuestas = {
    "¿Qué es una alimentación balanceada?": "Es una dieta que incluye todos los grupos de alimentos en proporciones adecuadas.",
    "¿Cuáles son los macronutrientes esenciales?": "Proteínas, carbohidratos y grasas.",
    "¿Por qué es importante beber agua?": "El agua ayuda en la digestión, circulación y eliminación de toxinas.",
    "¿Cuánta agua se recomienda al día?": "Se recomienda al menos 2 litros de agua al día.",
    "¿Qué alimentos son ricos en proteínas?": "Carne, huevos, legumbres y lácteos.",
    "¿Cuáles son fuentes saludables de grasas?": "Aguacate, frutos secos y aceite de oliva.",
    "¿Qué alimentos contienen fibra?": "Frutas, verduras, legumbres y cereales integrales.",
    "¿Por qué es importante el desayuno?": "El desayuno proporciona energía para comenzar el día.",
    "¿Qué efectos tiene el azúcar en exceso?": "Puede causar obesidad, diabetes y problemas cardíacos.",
    "¿Cuáles son los beneficios de consumir frutas y verduras?": "Aportan vitaminas, minerales y antioxidantes esenciales."
};

function iniciarChat() {
    const nombre = document.getElementById("nombre").value;
    const chat = document.getElementById("chat");
    chat.innerHTML = `<p>Hola ${nombre}, bienvenido. Pregunta algo sobre alimentación.</p>`;
}

function enviarPregunta() {
    const pregunta = document.getElementById("pregunta").value;
    const chat = document.getElementById("chat");
    const respuesta = respuestas[pregunta] || "Lo siento, no tengo respuesta para esa pregunta.";

    chat.innerHTML += `<p><strong>Alumno:</strong> ${pregunta}</p>`;
    chat.innerHTML += `<p><strong>Chatbot:</strong> ${respuesta}</p>`;
}
