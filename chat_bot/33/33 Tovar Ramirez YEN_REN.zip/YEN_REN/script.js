document.getElementById('send-button').addEventListener('click', handleUserInput);
document.getElementById('user-input').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') handleUserInput();
});

const responses = {
    futbol: [
        "¿Cuántos jugadores hay en un equipo de fútbol? - 11 jugadores.",
        "¿Cuánto dura un partido de fútbol? - 90 minutos, dividido en dos tiempos.",
        "¿Quién ganó el Mundial de 2018? - Francia.",
        "¿Qué es un fuera de juego? - Es cuando un jugador está más cerca de la portería rival que el penúltimo defensor al recibir el balón.",
        "¿Qué es un hat-trick? - Cuando un jugador anota tres goles en un partido.",
        "¿Qué es un penalti? - Es un tiro libre directo desde el área chica.",
        "¿Quién es el máximo goleador histórico? - Cristiano Ronaldo en competiciones oficiales.",
        "¿Qué equipo tiene más Champions League? - Real Madrid.",
        "¿Qué es un córner? - Es un saque desde la esquina del campo.",
        "¿Qué es un derby? - Es un partido entre equipos de la misma región."
    ],
    redes_sociales: [
        "¿Qué es Instagram? - Es una red social para compartir fotos y videos.",
        "¿Qué es TikTok? - Es una plataforma de videos cortos y creativos.",
        "¿Cuál es la red social más usada? - Facebook sigue siendo una de las más populares.",
        "¿Qué es un hashtag? - Es una etiqueta que clasifica contenido.",
        "¿Cómo ganar seguidores? - Crea contenido auténtico y regular.",
        "¿Qué son las historias? - Contenido temporal que dura 24 horas.",
        "¿Qué es un influencer? - Alguien con gran impacto en redes sociales.",
        "¿Qué es un DM? - Un mensaje directo.",
        "¿Qué es un algoritmo? - Es el sistema que decide qué contenido mostrar.",
        "¿Qué es la verificación? - Una insignia que confirma la autenticidad de una cuenta."
    ],
    algebra: [
        "¿Qué es el álgebra? - Es una rama de las matemáticas que utiliza letras y símbolos.",
        "¿Qué es una ecuación lineal? - Es una ecuación de primer grado.",
        "¿Cómo resolver x + 2 = 5? - x = 3.",
        "¿Qué es un polinomio? - Es una expresión algebraica con términos variables.",
        "¿Qué es una raíz cuadrada? - Es el número que multiplicado por sí mismo da el original.",
        "¿Qué es el teorema de Pitágoras? - En un triángulo rectángulo: a² + b² = c².",
        "¿Qué es una función cuadrática? - Es una función con la forma ax² + bx + c.",
        "¿Qué es una incógnita? - Es el valor desconocido que se busca en una ecuación.",
        "¿Qué es un término constante? - Es un número sin variable.",
        "¿Qué es una desigualdad? - Una expresión matemática que usa <, >, ≤, o ≥."
    ],
    maquillaje: [
        "¿Qué es un primer? - Es una base para preparar la piel.",
        "¿Qué es un iluminador? - Producto que resalta ciertas áreas.",
        "¿Qué es un contorno? - Se usa para definir y esculpir el rostro.",
        "¿Qué es una base de maquillaje? - Es el producto que unifica el tono de la piel.",
        "¿Qué son sombras de ojos? - Productos para maquillar los párpados.",
        "¿Qué es un labial mate? - Un lápiz labial sin brillo.",
        "¿Qué es un corrector? - Se usa para cubrir imperfecciones.",
        "¿Qué es un delineador? - Producto para marcar los ojos.",
        "¿Qué es una brocha kabuki? - Una brocha densa para productos en polvo.",
        "¿Cómo fijar el maquillaje? - Usando un spray fijador."
    ],
    alimentacion: [
        "¿Qué es una dieta balanceada? - Una dieta que incluye todos los grupos alimenticios.",
        "¿Cuántas comidas debo hacer al día? - 5 comidas: 3 principales y 2 ligeras.",
        "¿Qué son proteínas? - Nutrientes esenciales para los músculos.",
        "¿Qué es una dieta cetogénica? - Baja en carbohidratos y alta en grasas.",
        "¿Qué son carbohidratos? - Fuente principal de energía.",
        "¿Qué es la fibra? - Sustancia que mejora la digestión.",
        "¿Qué alimentos contienen hierro? - Espinacas, carne roja, legumbres.",
        "¿Cuánta agua debo tomar? - 2-3 litros diarios.",
        "¿Qué es el ayuno intermitente? - Alternar periodos de comer y ayunar.",
        "¿Qué son grasas saludables? - Aquellas de origen vegetal, como aguacate y nueces."
    ],
    gym: [
        "¿Qué es el entrenamiento de fuerza? - Ejercicios para ganar músculo.",
        "¿Qué es el cardio? - Ejercicios para mejorar la salud cardiovascular.",
        "¿Qué es una rutina dividida? - Entrenar grupos musculares específicos cada día.",
        "¿Cuánto tiempo debo entrenar? - 45-60 minutos es ideal.",
        "¿Qué es un calentamiento? - Ejercicios ligeros antes de entrenar.",
        "¿Qué es el enfriamiento? - Estiramientos después de entrenar.",
        "¿Qué es un press de banca? - Ejercicio para el pecho.",
        "¿Qué es una sentadilla? - Ejercicio para glúteos y piernas.",
        "¿Qué son repeticiones? - Número de veces que se realiza un ejercicio.",
        "¿Qué es una super-serie? - Dos ejercicios realizados sin descanso."
    ]
};

function handleUserInput() {
    const userInput = document.getElementById('user-input').value.toLowerCase().trim();
    const chatBox = document.getElementById('chat-box');

    if (userInput) {
        addMessage(userInput, 'user-message');
        const topic = Object.keys(responses).find(key => userInput.includes(key));
        const reply = topic
            ? getRandomResponse(responses[topic])
            : "Lo siento, no entiendo tu pregunta. Intenta incluir el tema (futbol, redes sociales, álgebra, maquillaje, alimentación, gym).";
        addMessage(reply, 'bot-message');
        document.getElementById('user-input').value = '';
    }
}

function addMessage(text, className) {
    const messageDiv = document.createElement('div');
    messageDiv.textContent = text;
    messageDiv.className = message ${className};
    document.getElementById('chat-box').appendChild(messageDiv);
    document.getElementById('chat-box').scrollTop = document.getElementById('chat-box').scrollHeight;
}

function getRandomResponse(array) {
    return array[Math.floor(Math.random() * array.length)];
}