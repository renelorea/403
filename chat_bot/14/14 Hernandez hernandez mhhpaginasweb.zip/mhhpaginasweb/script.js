const answers = {
    1: "Para una piel perfecta, puedes usar una buena base, corrector y un iluminador. Asegúrate de preparar tu piel con una crema hidratante primero.",
    2: "Para un maquillaje natural, usa una base ligera, un poco de corrector en las imperfecciones, rubor suave y un toque de mascara de pestañas.",
    3: "Para un evento nocturno, puedes optar por un maquillaje más dramático, con ojos ahumados, delineado fuerte y labios rojos.",
    4: "El contouring es una técnica de maquillaje que se usa para esculpir y definir el rostro, destacando los pómulos, la nariz y la mandíbula.",
    5: "Si tienes la piel seca, busca una base hidratante. Para pieles grasas, opta por bases matificantes.",
    6: "El iluminador se aplica en las zonas altas del rostro: pómulos, arco de cupido, puente de la nariz y en el centro de la frente.",
    7: "El primer es un producto que se aplica antes de la base para preparar la piel, minimizar poros y hacer que el maquillaje dure más.",
    8: "Los tonos suaves como los tonos champagne, rosados y marrones funcionan bien para pieles claras.",
    9: "Para elegir un buen labial, ten en cuenta el color de tu piel. Los tonos rojos y nude son versátiles, pero los tonos cálidos complementan mejor las pieles oscuras.",
    10: "Existen varios tipos de correctores: líquidos, en crema y en barra. Los líquidos son ideales para cubrir imperfecciones, mientras que los en crema son perfectos para ojeras."
};

function askQuestion(questionNumber) {
    // Agregar la pregunta como si el usuario la hubiera escrito
    const questionText = document.querySelector(`button[onclick='askQuestion(${questionNumber})']`).innerText;
    addMessage(questionText, 'user'); // Muestra la pregunta como mensaje del usuario

    // Responder con la respuesta del chatbot
    setTimeout(() => {
        const answer = answers[questionNumber];
        addMessage(answer, 'bot'); // Muestra la respuesta como mensaje del bot
    }, 500);
}

function sendMessage() {
    const userMessage = document.getElementById('user-input').value;
    if (userMessage.trim() === '') return;

    addMessage(userMessage, 'user');
    document.getElementById('user-input').value = '';

    setTimeout(() => {
        addMessage("Lo siento, no tengo información sobre eso en este momento.", 'bot');
    }, 500);
}

function addMessage(message, sender) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.classList.add('message');
    messageElement.classList.add(`${sender}-message`);
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;  // Auto-scroll to the bottom
}
