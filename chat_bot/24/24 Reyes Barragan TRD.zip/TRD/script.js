const respuestas = [
    // Preguntas comunes...
    { palabras: ["canelo", "quién"], respuesta: "Canelo Álvarez es un boxeador profesional mexicano, campeón mundial en varias divisiones." },
    { palabras: ["qué", "boxeo"], respuesta: "El boxeo es un deporte de combate donde dos personas luchan usando guantes." },
    { palabras: ["para", "qué", "guantes"], respuesta: "Los guantes protegen las manos del boxeador y reducen el daño al oponente." },
    { palabras: ["cuánto", "dura", "pelea"], respuesta: "Una pelea profesional puede durar hasta 12 rounds de 3 minutos cada uno." },
    { palabras: ["qué", "necesita", "boxear"], respuesta: "Se necesita entrenamiento, disciplina, guantes y protección adecuada." },
    { palabras: ["dónde", "nació", "boxeo"], respuesta: "El boxeo moderno se originó en Inglaterra en el siglo XVIII." },
    { palabras: ["cuántas", "divisiones"], respuesta: "Hay 17 divisiones de peso en el boxeo profesional." },
    { palabras: ["qué", "ko", "técnico"], respuesta: "Es cuando el árbitro detiene la pelea por seguridad del boxeador." },
    { palabras: ["estilos", "boxeo"], respuesta: "Hay estilos como el fajador, estilista, contragolpeador y más." },
    { palabras: ["organizaciones", "boxeo"], respuesta: "Las principales son CMB, AMB, FIB y OMB." },
    { palabras: ["libra", "por", "libra"], respuesta: "Es una lista de los mejores boxeadores sin importar el peso que compiten." }
];

function sendMessage() {
    const input = document.getElementById("user-input");
    const chatBox = document.getElementById("chat-box");
    const pregunta = input.value.trim().toLowerCase();

    if (!pregunta) return;

    // Mostrar la burbuja del usuario
    chatBox.innerHTML += `<div class="message-box user"><strong>Tú:</strong> ${pregunta}</div>`;

    let respuesta = "Lo siento, no tengo información sobre eso. Intenta reformular tu pregunta.";
    for (const obj of respuestas) {
        if (obj.palabras.every(palabra => pregunta.includes(palabra))) {
            respuesta = obj.respuesta;
            break;
        }
    }

    // Mostrar la burbuja del bot
    setTimeout(() => {
        chatBox.innerHTML += `<div class="message-box bot"><strong>BoxeoBot:</strong> ${respuesta}</div>`;
        speak(respuesta);
        chatBox.scrollTop = chatBox.scrollHeight;
    }, 500);

    input.value = "";
}

function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'es-ES';
    speechSynthesis.speak(utterance);
}

function iniciarEscucha() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
        alert("Tu navegador no soporta reconocimiento de voz");
        return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "es-ES";
    recognition.interimResults = false;

    recognition.start();

    recognition.onresult = function(event) {
        const resultado = event.results[0][0].transcript;
        document.getElementById("user-input").value = resultado;
        sendMessage();
    };

    recognition.onerror = function(event) {
        alert("Error de reconocimiento: " + event.error);
    };
}
