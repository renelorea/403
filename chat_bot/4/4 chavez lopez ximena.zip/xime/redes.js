const responses = {
    "¿Qué son las redes sociales?": "Las redes sociales son plataformas digitales que permiten la interacción entre personas y comunidades.",
    "¿Cuáles son las redes sociales más populares?": "Algunas de las redes más populares son Facebook, Instagram, Twitter, TikTok y LinkedIn.",
    "¿Cómo puedo proteger mi privacidad en redes sociales?": "Puedes mejorar tu privacidad ajustando la configuración de seguridad, evitando compartir información sensible y utilizando contraseñas seguras.",
    "¿Qué riesgos existen en las redes sociales?": "Los riesgos incluyen el ciberacoso, la exposición a contenido inapropiado y el robo de identidad.",
    "¿Cómo puedo ganar seguidores en redes sociales?": "Publica contenido de calidad, interactúa con tu audiencia y usa hashtags relevantes.",
    "¿Es recomendable compartir información personal en redes?": "No es recomendable compartir información sensible como dirección, teléfono o datos bancarios.",
    "¿Las redes sociales afectan la salud mental?": "Sí, el uso excesivo puede causar ansiedad y estrés. Es importante equilibrar el tiempo en redes con otras actividades.",
    "¿Cómo puedo verificar si una noticia en redes sociales es falsa?": "Verifica la fuente, busca noticias en medios confiables y evita compartir contenido sin confirmación.",
    "¿Qué beneficios tienen las redes sociales?": "Facilitan la comunicación, permiten el aprendizaje y ayudan a promocionar negocios o proyectos personales.",
    "¿Cómo denunciar contenido inapropiado en redes sociales?": "Cada plataforma tiene opciones para reportar contenido dañino o cuentas sospechosas."
};

function sendMessage() {
    let userInput = document.getElementById("user-input").value;
    let chatBox = document.getElementById("chat-box");

    if (responses[userInput]) {
        chatBox.innerHTML += `<p><strong>Tú:</strong> ${userInput}</p>`;
        chatBox.innerHTML += `<p><strong>Bot:</strong> ${responses[userInput]}</p>`;
    } else {
        chatBox.innerHTML += `<p><strong>Bot:</strong> Lo siento, no tengo una respuesta para eso.</p>`;
    }

    document.getElementById("user-input").value = ""; // Limpiar el campo de entrada
    chatBox.scrollTop = chatBox.scrollHeight; // Desplazar hacia abajo automáticamente
}