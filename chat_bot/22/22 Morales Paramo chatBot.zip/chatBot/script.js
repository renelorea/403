const alumnos = {
    "juan": { color: "red", saludo: "¡Hola Juan! Soy tu asistente de fútbol ⚽" },
    "ana": { color: "purple", saludo: "¡Bienvenida Ana! Vamos a hablar de fútbol 🏆" },
    "pedro": { color: "orange", saludo: "¡Hola Pedro! Pregúntame sobre fútbol 🔥" }
  };
  
  const respuestas = [
    {
      claves: ["mundial", "2022"],
      respuesta: "🏆 Argentina ganó el Mundial de 2022."
    },
    {
      claves: ["jugadores", "equipo"],
      respuesta: "👥 En fútbol, hay 11 jugadores por equipo."
    },
    {
      claves: ["fuera de juego", "offside"],
      respuesta: "🚩 Es cuando un jugador está más cerca de la portería rival que el penúltimo defensor al recibir el balón."
    },
    {
      claves: ["hat-trick", "tres goles"],
      respuesta: "🎯 Un hat-trick es cuando un jugador marca 3 goles en un partido."
    },
    {
      claves: ["mundiales", "brasil"],
      respuesta: "🇧🇷 Brasil ha ganado 5 Copas del Mundo."
    },
    {
      claves: ["messi"],
      respuesta: "🧙‍♂️ Lionel Messi es uno de los mejores futbolistas de la historia."
    },
    {
      claves: ["penalti", "penal"],
      respuesta: "🎯 Un penalti es una falta dentro del área que concede un tiro directo desde el punto de penalti."
    },
    {
      claves: ["cuánto", "dura", "partido"],
      respuesta: "⏱️ Un partido dura 90 minutos, divididos en dos mitades de 45."
    },
    {
      claves: ["champions", "liga de campeones"],
      respuesta: "🌍 La Champions League es el torneo de clubes más importante de Europa."
    },
    {
      claves: ["cristiano ronaldo"],
      respuesta: "💪 Cristiano Ronaldo es un famoso futbolista portugués, múltiple ganador del Balón de Oro."
    }
  ];
  
  let alumnoActual = prompt("Escribe tu nombre para personalizar tu experiencia:").toLowerCase();
  let personalizacion = alumnos[alumnoActual] || { color: "black", saludo: "¡Hola! Vamos a hablar de fútbol ⚽" };
  
  document.addEventListener("DOMContentLoaded", () => {
    mostrarMensaje("bot", personalizacion.saludo, personalizacion.color);
    hablar(personalizacion.saludo);
  });
  
  function sendMessage() {
    const input = document.getElementById("user-input");
    const mensaje = input.value.toLowerCase();
    if (!mensaje) return;
  
    mostrarMensaje("user", mensaje, "green");
  
    const respuesta = obtenerRespuesta(mensaje);
    mostrarMensaje("bot", respuesta, personalizacion.color);
    hablar(respuesta);
  
    input.value = "";
  }
  
  function obtenerRespuesta(mensaje) {
    for (let item of respuestas) {
      if (item.claves.every(palabra => mensaje.includes(palabra))) {
        return item.respuesta;
      }
    }
    return "Lo siento, no conozco la respuesta a esa pregunta 😔";
  }
  
  function mostrarMensaje(autor, texto, color) {
    const chatBox = document.getElementById("chat-box");
    const mensajeDiv = document.createElement("div");
    mensajeDiv.className = autor;
    mensajeDiv.style.color = color;
    mensajeDiv.textContent = `${autor === "bot" ? "Bot" : alumnoActual}: ${texto}`;
    chatBox.appendChild(mensajeDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
  }
  
  function hablar(texto) {
    const voz = new SpeechSynthesisUtterance(texto);
    voz.lang = "es-ES";
    speechSynthesis.speak(voz);
  }
  