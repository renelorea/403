// CONFIGURACIÓN IMPORTANTE: Cambia estos valores por los tuyos
const EMAIL_CONFIG = {
    // Reemplaza con tu Service ID de EmailJS
    SERVICE_ID: 'service_78018iq',
    
    // Reemplaza con tu Template ID de EmailJS
    TEMPLATE_ID: 'template_gn1rmr1',
    
    // Reemplaza con tu Public Key de EmailJS
    PUBLIC_KEY: 'pER4gW7T1CgRj8JNK',
    
    // AQUÍ COLOCA TU CORREO ELECTRÓNICO donde quieres recibir los comentarios
    TO_EMAIL: 'overhickoryy@gmail.com'
};

// Inicializar EmailJS
(function() {
    emailjs.init(EMAIL_CONFIG.PUBLIC_KEY);
})();

// Elementos del DOM
const commentForm = document.getElementById('commentForm');
const submitBtn = document.getElementById('submitBtn');
const successMessage = document.getElementById('successMessage');
const errorMessage = document.getElementById('errorMessage');

// Función para mostrar estado de carga
function setLoadingState(isLoading) {
    if (isLoading) {
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;
        submitBtn.querySelector('.btn-text').textContent = 'Enviando...';
    } else {
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
        submitBtn.querySelector('.btn-text').textContent = 'Enviar Comentario';
    }
}

// Función para mostrar mensajes
function showMessage(type, duration = 5000) {
    // Ocultar todos los mensajes primero
    successMessage.classList.add('hidden');
    errorMessage.classList.add('hidden');
    
    // Mostrar el mensaje correspondiente
    if (type === 'success') {
        successMessage.classList.remove('hidden');
        successMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else if (type === 'error') {
        errorMessage.classList.remove('hidden');
        errorMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    
    // Ocultar el mensaje después del tiempo especificado
    setTimeout(() => {
        successMessage.classList.add('hidden');
        errorMessage.classList.add('hidden');
    }, duration);
}

// Función para limpiar el formulario
function clearForm() {
    commentForm.reset();
}

// Función para enviar el email
async function sendEmail(formData) {
    try {
        const templateParams = {
            to_email: EMAIL_CONFIG.TO_EMAIL,  // Tu correo electrónico
            from_name: formData.name,         // Nombre del usuario
            from_email: formData.email,       // Email del usuario
            message: formData.comment,        // Comentario del usuario
            reply_to: formData.email,         // Para que puedas responder directamente
            subject: `Nuevo comentario de ${formData.name}` // Asunto del email
        };

        const response = await emailjs.send(
            EMAIL_CONFIG.SERVICE_ID,
            EMAIL_CONFIG.TEMPLATE_ID,
            templateParams
        );

        console.log('Email enviado exitosamente:', response);
        return { success: true, response };
    } catch (error) {
        console.error('Error al enviar email:', error);
        return { success: false, error };
    }
}

// Validación del formulario
function validateForm(formData) {
    const errors = [];
    
    // Validar nombre
    if (!formData.name.trim()) {
        errors.push('El nombre es requerido');
    } else if (formData.name.trim().length < 2) {
        errors.push('El nombre debe tener al menos 2 caracteres');
    }
    
    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
        errors.push('El correo electrónico es requerido');
    } else if (!emailRegex.test(formData.email)) {
        errors.push('El correo electrónico no es válido');
    }
    
    // Validar comentario
    if (!formData.comment.trim()) {
        errors.push('El comentario es requerido');
    } else if (formData.comment.trim().length < 10) {
        errors.push('El comentario debe tener al menos 10 caracteres');
    }
    
    return {
        isValid: errors.length === 0,
        errors: errors
    };
}

// Función principal para manejar el envío del formulario
async function handleFormSubmit(event) {
    event.preventDefault();
    
    // Ocultar mensajes previos
    successMessage.classList.add('hidden');
    errorMessage.classList.add('hidden');
    
    // Obtener datos del formulario
    const formData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        comment: document.getElementById('comment').value
    };
    
    // Validar formulario
    const validation = validateForm(formData);
    if (!validation.isValid) {
        alert('Por favor, corrige los siguientes errores:\n\n' + validation.errors.join('\n'));
        return;
    }
    
    // Verificar configuración de EmailJS
    if (EMAIL_CONFIG.SERVICE_ID === 'TU_SERVICE_ID' || 
        EMAIL_CONFIG.TEMPLATE_ID === 'TU_TEMPLATE_ID' || 
        EMAIL_CONFIG.PUBLIC_KEY === 'TU_PUBLIC_KEY') {
        alert('Error: Debes configurar EmailJS primero.\n\nRevisa las instrucciones en el archivo script.js');
        return;
    }
    
    // Mostrar estado de carga
    setLoadingState(true);
    
    try {
        // Enviar email
        const result = await sendEmail(formData);
        
        if (result.success) {
            // Éxito
            showMessage('success');
            clearForm();
            
            // Log para debugging
            console.log('Comentario enviado exitosamente:', {
                from: formData.name,
                email: formData.email,
                timestamp: new Date().toISOString()
            });
        } else {
            // Error en el envío
            showMessage('error');
            console.error('Error al enviar:', result.error);
        }
    } catch (error) {
        // Error inesperado
        showMessage('error');
        console.error('Error inesperado:', error);
    } finally {
        // Quitar estado de carga
        setLoadingState(false);
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Agregar event listener al formulario
    commentForm.addEventListener('submit', handleFormSubmit);
    
    // Mejorar UX con efectos en los inputs
    const inputs = document.querySelectorAll('.form-input, .form-textarea');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
        });
    });
    
    // Validación en tiempo real (opcional)
    const emailInput = document.getElementById('email');
    emailInput.addEventListener('blur', function() {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (this.value && !emailRegex.test(this.value)) {
            this.style.borderColor = '#ef4444';
        } else {
            this.style.borderColor = '#e5e7eb';
        }
    });
    
    console.log('Sistema de comentarios inicializado correctamente');
    console.log('Recuerda configurar EmailJS para que funcione el envío de emails');
});

// Funciones de utilidad adicionales
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Auto-resize del textarea
document.addEventListener('DOMContentLoaded', function() {
    const textarea = document.getElementById('comment');
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
});
