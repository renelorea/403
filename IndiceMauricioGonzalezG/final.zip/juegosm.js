// Función para navegar a diferentes páginas
function navigateTo(page) {
    // Efecto de transición antes de navegar
    const button = event.target.closest('.glass-button');
    
    // Añadir efecto de clic
    button.style.transform = 'scale(0.95)';
    button.style.transition = 'transform 0.1s ease';
    
    // Crear efecto de ondas
    createRippleEffect(event);
    
    // Navegar después de un pequeño delay para mostrar la animación
    setTimeout(() => {
        window.location.href = page;
    }, 200);
}

// Función para crear efecto de ondas al hacer clic
function createRippleEffect(event) {
    const button = event.target.closest('.glass-button');
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    const ripple = document.createElement('div');
    ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.6) 0%, transparent 70%);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s linear;
        pointer-events: none;
        z-index: 10;
    `;
    
    button.appendChild(ripple);
    
    // Remover el elemento después de la animación
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Añadir CSS para la animación de ondas
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Efecto de paralaje suave para las burbujas
document.addEventListener('mousemove', (e) => {
    const bubbles = document.querySelectorAll('.bubble');
    const x = e.clientX / window.innerWidth;
    const y = e.clientY / window.innerHeight;
    
    bubbles.forEach((bubble, index) => {
        const speed = (index + 1) * 0.5;
        const xOffset = (x - 0.5) * speed * 10;
        const yOffset = (y - 0.5) * speed * 10;
        
        bubble.style.transform = `translate(${xOffset}px, ${yOffset}px)`;
    });
});

// Animación de entrada para el panel principal
window.addEventListener('load', () => {
    const panel = document.querySelector('.glass-panel');
    panel.style.opacity = '0';
    panel.style.transform = 'scale(0.9) translateY(50px)';
    panel.style.transition = 'all 1s ease-out';
    
    setTimeout(() => {
        panel.style.opacity = '1';
        panel.style.transform = 'scale(1) translateY(0)';
    }, 100);
});

// Efecto de hover para mejorar la experiencia de usuario
document.querySelectorAll('.glass-button').forEach(button => {
    button.addEventListener('mouseenter', () => {
        // Crear partículas flotantes al pasar el mouse
        createFloatingParticles(button);
    });
});

function createFloatingParticles(button) {
    const rect = button.getBoundingClientRect();
    
    for (let i = 0; i < 3; i++) {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: fixed;
            width: 4px;
            height: 4px;
            background: rgba(135, 206, 235, 0.8);
            border-radius: 50%;
            left: ${rect.left + Math.random() * rect.width}px;
            top: ${rect.top + Math.random() * rect.height}px;
            pointer-events: none;
            z-index: 1000;
            animation: floatUp 2s ease-out forwards;
        `;
        
        document.body.appendChild(particle);
        
        setTimeout(() => {
            particle.remove();
        }, 2000);
    }
}

// Añadir animación para las partículas flotantes
const particleStyle = document.createElement('style');
particleStyle.textContent = `
    @keyframes floatUp {
        0% {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
        100% {
            opacity: 0;
            transform: translateY(-100px) scale(0);
        }
    }
`;
document.head.appendChild(particleStyle);